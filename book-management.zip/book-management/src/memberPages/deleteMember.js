import React from 'react';
import { useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  TextField,
  CardActions,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from "@material-ui/core";
import AppBar from '@material-ui/core/AppBar'
import Toolbar from '@material-ui/core/Toolbar'
import { Link, withRouter } from 'react-router-dom'
import '../App.css';
import ctrl from '../API_Controllers/member_API.js'

export default function App() {

  const [values, setValues] = useState({
    memb_id: ""
  });

  const handleChange = (username) => (event) => {
    setValues({ ...values, [username]: event.target.value });
  };
  
  const clickSubmit = () => {
    const request_body = {
    memb_id: values.memb_id || undefined
    };

    
    console.log(request_body);
    ctrl.remove(request_body).then((data) => {
      try {
        if (data._memb_id) {
          setsuccess(true);
        }
      } catch {
        setError(true);
      }
      
    });
  };

  const [success, setsuccess] = useState(false);
  const [error, setError] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  return (
    <div>
      {/**Toolbar Start*/}
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" color="inherit">
            Library
          </Typography>
          <div>
            <Link to="/book/home">
              <Button>Books</Button>
            </Link>
            
            <Link to="/member/home">
              <Button>Members</Button>  
            </Link>

            <Link to="/publisher/home">
              <Button>Publishers</Button>  
            </Link>
            
          </div>
        </Toolbar>
      </AppBar>

      {/**Toolbar End*/}
      <Card>
        <CardContent>
          <Typography variant="h6">
            Delete Member
          </Typography>
          <TextField
            id="memb_id"
            label="memb_id"
            value={values.memb_id}
            onChange={handleChange("memb_id")}
            margin="normal"
          />
          
          
        </CardContent>
        <CardActions>
          <Button
            color="primary"
            variant="contained"
            onClick={clickSubmit}
          >
            Submit
          </Button>
        </CardActions>
      </Card>

      <Dialog open={error}>
        <DialogTitle>Error!</DialogTitle>
        <DialogContent>
          <DialogContentText>
            There has been an error. You need a valid member to delete.
          </DialogContentText>
          <Button
              color="primary"
              variant="contained"
              onClick={() => {setError(false)}}
            >
              Okay
            </Button>
        </DialogContent>
      </Dialog>

      <Dialog open={success}>
        <DialogTitle>Member Deleted!</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Member Deleted!
          </DialogContentText>
          <Button
              color="primary"
              variant="contained"
              onClick={() => {setsuccess(false)}}
            >
              Okay
            </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

