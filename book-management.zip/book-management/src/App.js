import React from 'react';

import './App.css';
import {Route, Routes, BrowserRouter}  from 'react-router-dom'
import Home from './home/homePage.js'
import CreateBook from './bookPages/createBook'
import DeleteBook from './bookPages/deleteBook'
import FindBook from './bookPages/findBook'
import UpdateBook from './bookPages/updateBook'
import CreateMember from './memberPages/createMember'
import DeleteMember from './memberPages/deleteMember'
import FindMember from './memberPages/findMember'
import UpdateMember from './memberPages/updateMember'
import CreatePublisher from './publisherPages/createPublisher'
import DeletePublisher from './publisherPages/deletePublisher'
import FindPublisher from './publisherPages/findPublisher'
import UpdatePublisher from './publisherPages/updatePublisher'
import BookHomePage from './home/bookHomePage.js'
import MemberHomePage from './home/memberHomePage.js'
import PublisherHomePage from './home/publisherHomePage.js'

export default function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/book/create" element={<CreateBook/>}/>
          <Route path="/book/delete" element={<DeleteBook/>}/>
          <Route path="/book/find" element={<FindBook/>}/>
          <Route path="/book/update" element={<UpdateBook/>}/>
          <Route path="/book/home" element={<BookHomePage/>}/>
        
          <Route path="/member/create" element={<CreateMember/>}/>
          <Route path="/member/delete" element={<DeleteMember/>}/>
          <Route path="/member/find" element={<FindMember/>}/>
          <Route path="/member/update" element={<UpdateMember/>}/>
          <Route path="/member/home" element={<MemberHomePage/>}/>
        
          <Route path="/publisher/create" element={<CreatePublisher/>}/>
          <Route path="/publisher/delete" element={<DeletePublisher/>}/>
          <Route path="/publisher/find" element={<FindPublisher/>}/>
          <Route path="/publisher/update" element={<UpdatePublisher/>}/>
          <Route path="/publisher/home" element={<PublisherHomePage/>}/>
        </Routes>
      </BrowserRouter>
    </>
    
  );
}
