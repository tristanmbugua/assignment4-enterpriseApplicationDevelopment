
const create = async (user) => {
    try {
        let response = await fetch('http://localhost:8084/Book', {
          method: 'POST',
          headers: {
            'Accept': 'application/json',
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
            'Connection': 'keep-alive'
          },
          mode: "cors",
          body: JSON.stringify(user)
        });
        if (response) {
          return await response.json();
        }
        return "Error: No response"
    } catch(err) {
      console.log(err)
    }
  }
  
  
  
  const remove = async (body) => {
    try {
      let response = await fetch(('http://localhost:8084/Book/' + body.book_id), {
        method: 'DELETE',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json'
        },
        mode: "cors"
      })
      return await response.json()
    } catch(err) {
      console.log(err)
    }
  }

  const list = async (body) => {
    try {
      let response = await fetch(('http://localhost:8084/Book/' + body.book_id), {
        method: 'GET',
        mode: "cors",
        credentials: "same-origin"
      })
      return await response.json()
    } catch(err) {
      console.log(err)
    }
  }
  
  const update = async (body) => {
    try {
      let response = await fetch(('http://localhost:8084/Book/' + body._book_id), {
        method: 'PUT',
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
        },
        mode: "cors",
        body: JSON.stringify(body)
      })
      
      return await response.json()
    } catch(err) {
      console.log(err)
    }
  }

  export default {
    create,
    list,
    update,
    remove
  };     