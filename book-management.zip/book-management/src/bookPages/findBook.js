import React from 'react';
import { useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  TextField,
  CardActions,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from "@material-ui/core";
import AppBar from '@material-ui/core/AppBar'
import Toolbar from '@material-ui/core/Toolbar'
import { Link, withRouter } from 'react-router-dom'
import '../App.css';
import ctrl from '../API_Controllers/book_API.js'

export default function App() {

  const [values, setValues] = useState({
    book_id: ""
  });

  const handleChange = (username) => (event) => {
    setValues({ ...values, [username]: event.target.value });
  };


    const [author, setAuthor] = useState("")
    const [title, setTitle] = useState("")
    const [price, setPrice] = useState("")

  const clickSubmit = () => {
    const request_body = {
    book_id: values.book_id || undefined
    };

    
    console.log(request_body);
    ctrl.list(request_body).then((data) => {
      try {
        console.log(data);
        if (data._book_id) {
          setsuccess(true);
          setAuthor(data._author);
          setTitle(data._title);
          setPrice(data._price);
        }
      } catch {
        setError(true);
      }
      
    });
  };

  const [success, setsuccess] = useState(false);
  const [error, setError] = useState(false);

  return (
    <div>
      {/**Toolbar Start*/}
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" color="inherit">
            Library
          </Typography>
          <div>
            <Link to="/book/home">
              <Button>Books</Button>
            </Link>
            
            <Link to="/member/home">
              <Button>Members</Button>  
            </Link>

            <Link to="/publisher/home">
              <Button>Publishers</Button>  
            </Link>
            
          </div>
        </Toolbar>
      </AppBar>

      {/**Toolbar End*/}
      <Card>
        <CardContent>
          <Typography variant="h6">
            Find Book
          </Typography>
          <TextField
            id="book_id"
            label="book_id"
            value={values.book_id}
            onChange={handleChange("book_id")}
            margin="normal"
          />
          
          
        </CardContent>
        <CardActions>
          <Button
            color="primary"
            variant="contained"
            onClick={clickSubmit}
          >
            Submit
          </Button>
        </CardActions>
      </Card>

      <Dialog open={error}>
        <DialogTitle>Error!</DialogTitle>
        <DialogContent>
          <DialogContentText>
            There has been an error. You need a valid book to find.
          </DialogContentText>
          <Button
              color="primary"
              variant="contained"
              onClick={() => {setError(false)}}
            >
              Okay
            </Button>
        </DialogContent>
      </Dialog>

      <Dialog open={success}>
        <DialogTitle>Book Found!</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Book Found!{<br/>}{<br/>}
            Author: {author}{<br/>}
            Title: {title}{<br/>}
            Price: {price}{<br/>}

          </DialogContentText>
          <Button
              color="primary"
              variant="contained"
              onClick={() => {setsuccess(false)}}
            >
              Okay.
            </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

