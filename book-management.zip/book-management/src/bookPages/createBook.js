  import React from 'react';
  import { useState } from 'react';
  import {
    Card,
    CardContent,
    Typography,
    TextField,
    CardActions,
    Button,
    Dialog,
    DialogTitle,
    DialogContent,
    DialogContentText,
    DialogActions,
  } from "@material-ui/core";
  import AppBar from '@material-ui/core/AppBar'
import Toolbar from '@material-ui/core/Toolbar'
import { Link, withRouter } from 'react-router-dom'
  import '../App.css';
  import ctrl from '../API_Controllers/book_API.js'

  export default function App() {

    const [values, setValues] = useState({
      _book_id: ""
      ,_author:""
      ,_title:""
      ,_price:""
      ,_available:""
      ,_dueDate:""
      ,_returnDate:""
      ,_issue:""
      ,_pub_id:""
      ,_memb_id:""
    });

    const handleChange = (username) => (event) => {
      setValues({ ...values, [username]: event.target.value });
    };
    
    const clickSubmit = () => {
      const request_body = {
      _book_id: values._book_id || undefined
      ,_author: values._author || undefined
      ,_title: values._title || undefined
      ,_price: parseFloat(values._price) || undefined
      ,_available: values._available || undefined
      ,_dueDate: values._dueDate || undefined
      ,_returnDate: values._returnDate || undefined
      ,_issue: parseInt(values._issue) || undefined
      ,_pub_id: values._pub_id || undefined
      ,_memb_id: values._memb_id || undefined
      };

      
      console.log(request_body);
      ctrl.create(request_body).then((data) => {
        
        console.log(data);
        try {
          if (typeof data._author !== 'undefined') {
            setsuccess(true);
          }
        } catch {
          setError(true);
          setErrorMessage(data);
        }
      });
    };

    const [success, setsuccess] = useState(false);
    const [error, setError] = useState(false);
    const [errorMessage, setErrorMessage] = useState("");

    return (
      <div>
        {/**Toolbar Start*/}
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" color="inherit">
            Library
          </Typography>
          <div>
            <Link to="/book/home">
              <Button>Books</Button>
            </Link>
            
            <Link to="/member/home">
              <Button>Members</Button>  
            </Link>

            <Link to="/publisher/home">
              <Button>Publishers</Button>  
            </Link>
            
          </div>
        </Toolbar>
      </AppBar>

      {/**Toolbar End*/}
        <Card>
          <CardContent>
            <Typography variant="h6">
              Create Book
            </Typography>
            <TextField
              id="_book_id"
              label="_book_id"
              value={values._book_id}
              onChange={handleChange("_book_id")}
              margin="normal"
            />{"\t"}
            
    
            <TextField
              id="_author"
              label="_author"
              value={values._author}
              onChange={handleChange("_author")}
              margin="normal"
            />{"\t"}
    
    
            <TextField
              id="_title"
              label="_title"
              value={values._title}
              onChange={handleChange("_title")}
              margin="normal"
            /><br/>
    
            <TextField
              id="_price"
              label="_price"
              value={values._price}
              onChange={handleChange("_price")}
              margin="normal"
            />{"\t"}
        
    
            <TextField
              id="_available"
              label="_available"
              value={values._available}
              onChange={handleChange("_available")}
              margin="normal"
            />{"\t"}
            
    
            <TextField
              id="_dueDate"
              label="_dueDate"
              value={values._dueDate}
              onChange={handleChange("_dueDate")}
              margin="normal"
            /><br/>
          
    
            <TextField
              id="_returnDate"
              label="_returnDate"
              value={values._returnDate}
              onChange={handleChange("_returnDate")}
              margin="normal"
            />{"\t"}
            
    
            <TextField
              id="_issue"
              label="_issue"
              value={values._issue}
              onChange={handleChange("_issue")}
              margin="normal"
            />{"\t"}
        
    
            <TextField
              id="_pub_id"
              label="_pub_id"
              value={values._pub_id}
              onChange={handleChange("_pub_id")}
              margin="normal"
            /><br/>
          
    
            <TextField
              id="_memb_id"
              label="_memb_id"
              value={values._memb_id}
              onChange={handleChange("_memb_id")}
              margin="normal"
            />
            
          </CardContent>
          <CardActions>
            <Button
              color="primary"
              variant="contained"
              onClick={clickSubmit}
            >
              Submit
            </Button>
          </CardActions>
        </Card>

        <Dialog open={error}>
          <DialogTitle>Error!</DialogTitle>
          <DialogContent>
            <DialogContentText>
              There has been an error. Please check all inputs.
            </DialogContentText>
            <Button
              color="primary"
              variant="contained"
              onClick={() => {setError(false)}}
            >
              Okay
            </Button>
          </DialogContent>
        </Dialog>

        <Dialog open={success}>
          <DialogTitle>Book created!</DialogTitle>
          <DialogContent>
            <DialogContentText>
              Book created!
            </DialogContentText>
            <Button
              color="primary"
              variant="contained"
              onClick={() => {setsuccess(false)}}
            >
              Okay
            </Button>
          </DialogContent>
        </Dialog>
      </div>
    );
  }

