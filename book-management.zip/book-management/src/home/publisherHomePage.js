import React from 'react';
import {
    Card,
    Typography,
    Button
  } from "@material-ui/core";
  import AppBar from '@material-ui/core/AppBar'
  import Toolbar from '@material-ui/core/Toolbar'
  import { Link, withRouter } from 'react-router-dom'
import '../App.css';

export default function App() {
  return (
    <>
    <div>
      {/**Toolbar Start*/}
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" color="inherit">
            Library
          </Typography>
          <div>
            <Link to="/book/home">
              <Button>Books</Button>
            </Link>
            
            <Link to="/member/home">
              <Button>Members</Button>  
            </Link>

            <Link to="/publisher/home">
              <Button>Publishers</Button>  
            </Link>
            
          </div>
        </Toolbar>
      </AppBar>

      {/**Toolbar End*/}

      <Card>
            <Link to="/publisher/create">
                <Button>Create Publisher</Button>
            </Link>

            <Link to="/publisher/delete">
                <Button>Delete Publisher</Button>
            </Link>

            <Link to="/publisher/find">
                <Button>Find Publisher</Button>
            </Link>

            <Link to="/publisher/update">
                <Button>Update Publisher</Button>
            </Link>
      </Card>
      </div>
    </>
  );
}