import React from 'react';
import { useState } from 'react';
import {
  Card,
  CardContent,
  Typography,
  TextField,
  CardActions,
  Button,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
} from "@material-ui/core";
import AppBar from '@material-ui/core/AppBar'
import Toolbar from '@material-ui/core/Toolbar'
import { Link, withRouter } from 'react-router-dom'
import '../App.css';
import ctrl from '../API_Controllers/publisher_API.js'

export default function App() {

  const [values, setValues] = useState({
    pub_id: ""
  });

  const handleChange = (username) => (event) => {
    setValues({ ...values, [username]: event.target.value });
  };


    const [address, setAddress] = useState("")
    const [name, setName] = useState("")
    

  const clickSubmit = () => {
    const request_body = {
    pub_id: values.pub_id || undefined
    };

    
    console.log(request_body);
    ctrl.list(request_body).then((data) => {
      try {
        console.log(data);
        if (data._pub_id) {
          setsuccess(true);
          setAddress(data._address);
          setName(data._name);
        }
      } catch {
        setError(true);
      }
      
    });
  };

  const [success, setsuccess] = useState(false);
  const [error, setError] = useState(false);

  return (
    <div>
      {/**Toolbar Start*/}
      <AppBar position="static">
        <Toolbar>
          <Typography variant="h6" color="inherit">
            Library
          </Typography>
          <div>
            <Link to="/book/home">
              <Button>Books</Button>
            </Link>
            
            <Link to="/member/home">
              <Button>Members</Button>  
            </Link>

            <Link to="/publisher/home">
              <Button>Publishers</Button>  
            </Link>
            
          </div>
        </Toolbar>
      </AppBar>

      {/**Toolbar End*/}
      <Card>
        <CardContent>
          <Typography variant="h6">
            Find Publisher
          </Typography>
          <TextField
            id="pub_id"
            label="pub_id"
            value={values.pub_id}
            onChange={handleChange("pub_id")}
            margin="normal"
          />
          
          
        </CardContent>
        <CardActions>
          <Button
            color="primary"
            variant="contained"
            onClick={clickSubmit}
          >
            Submit
          </Button>
        </CardActions>
      </Card>

      <Dialog open={error}>
        <DialogTitle>Error!</DialogTitle>
        <DialogContent>
          <DialogContentText>
            There has been an error. You need a valid book to find.
          </DialogContentText>
          <Button
              color="primary"
              variant="contained"
              onClick={() => {setError(false)}}
            >
              Okay
            </Button>
        </DialogContent>
      </Dialog>

      <Dialog open={success}>
        <DialogTitle>Publisher Found!</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Publisher Found!{<br/>}{<br/>}
            Address: {address}{<br/>}
            Name: {name}{<br/>}

          </DialogContentText>
          <Button
              color="primary"
              variant="contained"
              onClick={() => {setsuccess(false)}}
            >
              Okay.
            </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}

